
bloem = 500/20
melk = 800/20
eieren = 3/20
zout = 1/20  
boter = 30/20   
suiker = 100/20

aantal = (input('hoeveel taarten wil je')
bloem = aantal * bloem
melk = aantal * melk
eieren = aantal * eieren
zout = aantal * zout
boter = aantal * boter
suiker = aantal * suiker

print(f'voor {aantal} taarten heeft u nodig:')
print(f'{bloem} g bloem nodig' )
print(f'{melk} ml melk nodig ' )
print(f"{eieren} eieren" )
print(f'[zout] tl zout' )
print(f'{boter} g boter' )
print(f'{suiker} g boter' )
 